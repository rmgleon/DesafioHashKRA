#ifndef BUSQUEDA_HASH_H
#define BUSQUEDA_HASH_H

void FHash ( list *cadena[] );

#endif /* BUSQUEDA_HASH_H */
